settings = {
    'host': '[YOUR ENDPOINT]',
    'master_key': '[YOUR KEY]',
    'database_id': 'pysamples',
    'collection_id': 'data'
}